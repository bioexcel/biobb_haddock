################################################################################
# Information about configuration files present in the same directory #
################################################################################
"/tmp/biobb/unitests_6/haddock3_extend/sandbox_b9162a8d-bc8c-440c-9825-6daea600d2c6/2261594f-52d2-467a-906b-e970e6d6ce5f/data/configurations/raw_input.toml": An untouched copy of the raw input file, as provided by the user.
"/tmp/biobb/unitests_6/haddock3_extend/sandbox_b9162a8d-bc8c-440c-9825-6daea600d2c6/2261594f-52d2-467a-906b-e970e6d6ce5f/data/configurations/cleaned_input.toml": Pre-parsed input file where (eventually) some indexing and modifications were applied to ensure further processing.
"/tmp/biobb/unitests_6/haddock3_extend/sandbox_b9162a8d-bc8c-440c-9825-6daea600d2c6/2261594f-52d2-467a-906b-e970e6d6ce5f/data/configurations/enhanced_haddock_params.toml": Final input file with detailed default parameters.
