################################################################################
# Information about configuration files present in the same directory #
################################################################################
"0f835bb0-3b5c-446d-adb8-2029d573b809/data/configurations/raw_input.toml": An untouched copy of the raw input file, as provided by the user.
"0f835bb0-3b5c-446d-adb8-2029d573b809/data/configurations/cleaned_input.toml": Pre-parsed input file where (eventually) some indexing and modifications were applied to ensure further processing.
"0f835bb0-3b5c-446d-adb8-2029d573b809/data/configurations/enhanced_haddock_params.toml": Final input file with detailed default parameters.
