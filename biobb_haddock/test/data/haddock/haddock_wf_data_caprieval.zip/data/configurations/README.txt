################################################################################
# Information about configuration files present in the same directory #
################################################################################
"/tmp/biobb/unitests_108/capri_eval/sandbox_8a55dead-283e-4595-b50d-30627a373ca7/380ed2ef-0ce5-4990-b041-01730f11c284/data/configurations/raw_input.toml": An untouched copy of the raw input file, as provided by the user.
"/tmp/biobb/unitests_108/capri_eval/sandbox_8a55dead-283e-4595-b50d-30627a373ca7/380ed2ef-0ce5-4990-b041-01730f11c284/data/configurations/cleaned_input.toml": Pre-parsed input file where (eventually) some indexing and modifications were applied to ensure further processing.
"/tmp/biobb/unitests_108/capri_eval/sandbox_8a55dead-283e-4595-b50d-30627a373ca7/380ed2ef-0ce5-4990-b041-01730f11c284/data/configurations/enhanced_haddock_params.toml": Final input file with detailed default parameters.
