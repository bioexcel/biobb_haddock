# Usage

To view structures or download the structure files, in a terminal run the command:
```bash
python -m http.server --directory .
```
And open the link following links in a web browser:
- [2_caprieval_analysis/report.html](http://0.0.0.0:8000/2_caprieval_analysis/report.html) 
