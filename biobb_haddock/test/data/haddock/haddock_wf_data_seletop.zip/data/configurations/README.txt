################################################################################
# Information about configuration files present in the same directory #
################################################################################
"3a7017ce-da60-465c-9e84-8d2d9f6ac8df/data/configurations/raw_input.toml": An untouched copy of the raw input file, as provided by the user.
"3a7017ce-da60-465c-9e84-8d2d9f6ac8df/data/configurations/cleaned_input.toml": Pre-parsed input file where (eventually) some indexing and modifications were applied to ensure further processing.
"3a7017ce-da60-465c-9e84-8d2d9f6ac8df/data/configurations/enhanced_haddock_params.toml": Final input file with detailed default parameters.
