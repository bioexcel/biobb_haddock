################################################################################
# Information about configuration files present in the same directory #
################################################################################
"/tmp/biobb/unitests_117/sele_top/sandbox_a26273b8-f884-40f2-abb4-c263656f6f31/_run_dir0f5cf5ff-58f3-40f4-8936-d1910311d43f/data/configurations/raw_input.toml": An untouched copy of the raw input file, as provided by the user.
"/tmp/biobb/unitests_117/sele_top/sandbox_a26273b8-f884-40f2-abb4-c263656f6f31/_run_dir0f5cf5ff-58f3-40f4-8936-d1910311d43f/data/configurations/cleaned_input.toml": Pre-parsed input file where (eventually) some indexing and modifications were applied to ensure further processing.
"/tmp/biobb/unitests_117/sele_top/sandbox_a26273b8-f884-40f2-abb4-c263656f6f31/_run_dir0f5cf5ff-58f3-40f4-8936-d1910311d43f/data/configurations/enhanced_haddock_params.toml": Final input file with detailed default parameters.
