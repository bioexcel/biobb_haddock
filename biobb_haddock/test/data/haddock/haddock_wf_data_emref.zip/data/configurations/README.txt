################################################################################
# Information about configuration files present in the same directory #
################################################################################
"36bb919c-9148-42ed-988b-b26658afd486/data/configurations/raw_input.toml": An untouched copy of the raw input file, as provided by the user.
"36bb919c-9148-42ed-988b-b26658afd486/data/configurations/cleaned_input.toml": Pre-parsed input file where (eventually) some indexing and modifications were applied to ensure further processing.
"36bb919c-9148-42ed-988b-b26658afd486/data/configurations/enhanced_haddock_params.toml": Final input file with detailed default parameters.
